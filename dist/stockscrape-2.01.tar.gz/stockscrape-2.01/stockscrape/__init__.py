from stockscrape.ticker import Ticker
